#include "Polynomial.h"
#include <assert.h>

Polynomial::Polynomial(const vector<int> &coefficients) {
  coefficients_ = coefficients;
}

Polynomial::Polynomial(const Polynomial &other) {
  this->coefficients_ = other.coefficients_;
}

Polynomial add(const Polynomial &p1, const Polynomial &p2) {
  // TODO
  //从高到低
  Polynomial res;
  int lenth=0;
  int big=0;
    if (p1.coefficients_.size()>p2.coefficients_.size()){
        lenth=p2.coefficients_.size();
        big=p1.coefficients_.size();
        for (int i = 0; i < big-lenth; i++ ) {
            res.coefficients_.push_back(p1.coefficients_[i]);
        }
        for (int i = big-lenth; i <p1.coefficients_.size() ; i++) {
            res.coefficients_.push_back(p1.coefficients_[i]+p2.coefficients_[i-big+lenth]);
        }
    } else if (p2.coefficients_.size()>p1.coefficients_.size()){
        lenth=p1.coefficients_.size();
        big=p2.coefficients_.size();
        for (int i = 0; i < big-lenth; i++ ) {
            res.coefficients_.push_back(p2.coefficients_[i]);
        }
        for (int i = big-lenth; i < p2.coefficients_.size(); i++ ) {
            res.coefficients_.push_back(p2.coefficients_[i]+p1.coefficients_[i-big+lenth]);
        }
    } else{
        for (int i = 0; i < p1.coefficients_.size(); i++ ) {
            res.coefficients_.push_back(p1.coefficients_[i]+p2.coefficients_[i]);
        }
    }
    return res;
  
}
Polynomial derivate(const Polynomial &p) {
  // TODO
  Polynomial res;
    if (p.coefficients_.size()==1){
        res.coefficients_.push_back(0);
        return res;
    }
    for (int i = 0; i < p.coefficients_.size()-1; i++ ) {
        res.coefficients_.push_back((p.coefficients_.size()-i-1)*p.coefficients_[i]);
    }
    return res;
}

void Polynomial::output() const {
  // TODO
  int i= this->coefficients_.size()-1;
    if (i==0){
        if (this->coefficients_[0]!=0){
            cout<< this->coefficients_[0]<<"(0)"<<endl;
            return;
        } else{
            return;
        }
    }
    for (int j = 0; j < this->coefficients_.size(); j++ ) {
        if (this->coefficients_[j]!=0) {
            cout << this->coefficients_[j] << "(" << i << ")" << " ";
        }
        i--;
    }
    cout<<endl;
}
int main(){
    Polynomial t({4,0,3,2}); // x^2 + x + 1
    derivate(t).output(); // 2x + 1
//    Polynomial t({3, 0}); // 3x
//    t.output();
//    Polynomial t({2, 1, 0}); // 2x^2 + x
//    Polynomial t2({3}); // 3
//    add(t, t2).output();


}
