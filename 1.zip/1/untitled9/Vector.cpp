//
// Created by admin on 2023/3/28.
//
#include "Vector.h"
#include <iostream>
//bool large_than_zero(int a){
//    return a>0? true: false;
//}
Vector Vector::map(map_func f) const {
    // TODO
    vector<int> res;
    for (int i = 0; i < vec_.size(); i++ ) {
        res.push_back(f(vec_[i]));
    }
    return res;
}

Vector Vector::filter(filter_func f) const {
    // TODO
    vector<int> res;
    for (int i = 0; i < vec_.size(); i++ ) {
        if (f(vec_[i])== true){
            res.push_back(vec_[i]);
        }
    }
    return res;
}

Vector &Vector::for_each(map_func f) {
    // TODO
    for (int i = 0; i < vec_.size(); i++ ) {
        vec_[i]=f(vec_[i]);
    }
    return *this;
}

void Vector::output() const {
    // TODO
    for (int i = 0; i < vec_.size(); i++ ) {
        cout<<vec_[i]<<" ";
    }
    cout<<endl;
}
int main(){
    Vector foo({-1, 0, 1});
    foo.filter(large_than_zero).output();
    foo.output();

}