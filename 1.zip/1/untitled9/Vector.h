//
// Created by admin on 2023/3/28.
//

#ifndef UNTITLED9_VECTOR_H
#define UNTITLED9_VECTOR_H

#endif //UNTITLED9_VECTOR_H
#include <vector>
using namespace std;

typedef int (*map_func)(int);
typedef bool (*filter_func)(int);

class Vector {
public:
    Vector(const vector<int> &vec) : vec_(vec) {}

    Vector filter(filter_func f) const;
    Vector map(map_func f) const;
    Vector &for_each(map_func f);

    void output() const;

private:
    vector<int> vec_;
};