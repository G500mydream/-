//
// Created by admin on 2023/3/29.
////
//#include "bits/stdc++.h"
//#include "omp.h"
//using namespace std;
//
//int sum=0;
//#pragma omp parallel for reduction(+:sum)
//
//int n, q;
//int l, r;
//
//inline int add(int b[], int l, int r) {
//    for (int i = 0; i <= r - l; i++) {
//        sum += b[i + l - 1];
//    }
//    return sum;
//}
//
//int main() {
//    cin >> n >> q;
//    int arr[n] = {0};
//
//    for (int i = 0; i < n; i++) {
//        cin >> arr[i];
//    }
//    for (int i = 0; i < q; i++) {
//        cin >> l >> r;
//        cout << add(arr, l , r ) << endl;
//    }
//}
#include <vector>
#include <iostream>

using namespace std;

class SegmentTree {
public:
    SegmentTree(vector<int> &nums) {
        n = nums.size();
        tree.resize(n * 4);
        build(nums, 0, 0, n - 1);
    }

    int sum(int left, int right) {
        return sum(0, 0, n - 1, left, right);
    }

private:
    vector<int> tree;
    int n;

    void build(vector<int> &nums, int node, int left, int right) {
        if (left == right) {
            tree[node] = nums[left];
        } else {
            int mid = left + (right - left) / 2;
            build(nums, 2 * node + 1, left, mid);
            build(nums, 2 * node + 2, mid + 1, right);
            tree[node] = tree[2 * node + 1] + tree[2 * node + 2];
        }
    }

    int sum(int node, int left, int right, int i, int j) {
        if (i > right || j < left) {
            return 0;
        }
        if (i <= left && j >= right) {
            return tree[node];
        }
        int mid = left + (right - left) / 2;
        return sum(2 * node + 1, left, mid, i, j) + sum(2 * node + 2, mid + 1, right, i, j);
    }
};

int main() {
    int n, q;
    int tmp;
    int l, r;
    vector<int> nums;
    cin >> n >> q;
    for (int i = 0; i < n; i++) {
        cin >> tmp;
        nums.push_back(tmp);
    }
    SegmentTree tree(nums);
    for (int i = 0; i < q; i++) {
        cin >> l >> r;
        cout << tree.sum(l - 1, r - 1) << endl;
    }
    return 0;
}
