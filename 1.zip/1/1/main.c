#include <stdio.h>
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_ttf.h"
#include "windows.h"

int main(int,char **) {

    SDL_Window *window=NULL;
    window= SDL_CreateWindow("test",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,1000,800,SDL_WINDOW_SHOWN);
    Sleep(5000);
    SDL_DestroyWindow(window);
    printf("Hello, World!\n");
    return 0;
}
