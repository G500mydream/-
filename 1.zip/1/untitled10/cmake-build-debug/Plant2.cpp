//
// Created by admin on 2023/4/4.
//
#include"Plant.h"
int Plant2::sum = 0;
int Plant2::num = 0;
int Plant1::sum = 0;
void Plant1::beAttacked(int x)
{
    HP -= x;
    if (HP <= 0)
        this->~Plant1();
}

Plant1::Plant1(int price, int hp)
{
    this->price = price;
    this->HP = hp;
    sum += price;
}
Plant1::~Plant1()
{
    sum -= price;
}

Plant2::Plant2(int price)
{
    this->price = price;
    sum += price; num++;
}

Plant2::Plant2(const Plant2& p2)
{
    this->life = 0; num++;
    this->price = p2.price;
    this->time1 = p2.time1;
    this->time2 = p2.time2;
}
Plant2::~Plant2()
{
    num--;
}

void changePrice(Plant1& plant1, Plant2& plant2)
{
    int tmp = plant1.price;
    plant1.price = plant2.price;
    plant2.price = tmp;
    Plant1::sum -= plant2.price;
    Plant1::sum += plant1.price;
    Plant2::sum -= plant1.price;
    Plant2::sum += plant2.price;
}

int getTotalPrice()
{
    int sum;
    sum = Plant1::sum + Plant2::sum;
    return sum;
}

int getTotalPrice(const Plant1& plant1, const Plant1& plant2)
{
    int sum;
    sum = plant1.price + plant2.price;
    return sum;
}

int getTotalPlant1Price()
{
    int sum;
    sum = Plant1::sum;
    return sum;
}

//========
Plant2::Plant2(int price, int time1, int time2)
{
    this->price = price;
    this->time1 = time1;
    this->time2 = time2;
    life = 0;
    num++;
    sum += price;
}

void Plant2::func(int n)
{
    if (n > 0)
    {
        // int day = 0;//---生长天数
        while (life < n)
        {
            if (life >= time1 && life < time2)
            {
                Plant2* pnew = new Plant2(*this);
                pnew->func(n - life);
            }
            if (life == time2)
            {
                this->~Plant2();
                break;
            }
            this->life++;
        }
    }
}

int getTotalPlant2Num()
{
    return Plant2::num;
}