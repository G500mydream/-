//
// Created by admin on 2023/4/4.
//
#include"Plant.h"

int Plant1::total_price1 = 0;
int Plant2::total_price2 = 0;
int Plant2::cnt = 0;

int get_price(const Plant1 &obj) {
    return obj.price;
}

void Plant1::beAttacked(int x) {
    HP -= x;
    if (HP <= 0) {
        this->~Plant1();
    }
}

Plant1::Plant1(int price, int hp) {
    this->price = price;
    this->HP = hp;
    total_price1 += price;
}

Plant1::~Plant1() {
    Plant1::total_price1 -= price;
}

Plant2::Plant2(int price) {
    this->price = price;
    total_price2 += price;
    cnt++;
}

Plant2::Plant2(const Plant2 &p2) {
    this->life = 0;
    cnt++;
    this->price = p2.price;
    this->time1 = p2.time1;
    this->time2 = p2.time2;
    total_price2+=p2.price;
}

Plant2::~Plant2() {
    Plant2::total_price2 -= price;
    cnt--;
}

void changePrice(Plant1 &plant1, Plant2 &plant2) {
    int tmp1 = plant1.get_plant1_price();
    int tmp2 = plant2.get_plant2_price();
    Plant1::total_price1 -= tmp1;
    Plant2::total_price2 -= tmp2;
    plant1.set_plant1_price(tmp2);
    plant2.set_plant2_price(tmp1);
    Plant1::total_price1 += tmp2;
    Plant2::total_price2 += tmp1;
}

int getTotalPrice() {
    return Plant1::total_price1 + Plant2::total_price2;
}

int getTotalPrice(const Plant1 &plant1, const Plant1 &plant2) {
    return get_price(plant1) + get_price(plant2);
}

int getTotalPlant1Price() {
    return Plant1::total_price1;
}

//========
Plant2::Plant2(int price, int time1, int time2) {
    this->price = price;
    this->time1 = time1;
    this->time2 = time2;
    life=0;
    total_price2 += price;
    cnt++;
}

void Plant2::func(int n) {
    if (n > 0) {
        while (life < n) {
            if (life >= time1 && life < time2) {
                Plant2 *p = new Plant2(*this);
                p->func(n - life);
            }
            if (life == time2) {
                this->~Plant2();
                break;
            }
            this->life++;
        }
    }
}

int getTotalPlant2Num() {
    return Plant2::cnt;
}

int main() {
    //test1:
//    Plant1 t(20, 3);
//    Plant2 t3(40);
//    cout << getTotalPrice();
//test2:
//    Plant1 t(20, 3);
//    Plant2 t3(40);
//    changePrice(t, t3);
//    cout << getTotalPlant1Price();
////test3:
//    Plant2 t(4, 1, 3); //目前已有存活的植物t
//    t.func(4); //植物t被种植，即开始发挥功能，距离关卡结束还有4天
//    cout << getTotalPlant2Num(); //关卡结束，输出目前存活的植物数量

    Plant2 t(4, 1, 3);
    Plant2 t1(4, 1, 3);
    t.func(4);
    t1.func(4);
    cout << getTotalPlant2Num();

}