
#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define LENGTH 20 // 游戏场地长度
#define BLOCK_SIZE 30 // 方块大小
#define WINDOW_WIDTH LENGTH * BLOCK_SIZE // 窗口宽度
#define WINDOW_HEIGHT BLOCK_SIZE * 2 // 窗口高度
#define TREE 'T' // 树
#define ROCK 'R' // 石头
#define BLANK ' ' // 空白

int main(int argc, char *argv[]) {
    // 初始化 SDL
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }

    // 创建窗口
    SDL_Window *window = SDL_CreateWindow("滑雪大冒险", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                          WINDOW_WIDTH, WINDOW_HEIGHT, 0);
    if (window == NULL) {
        fprintf(stderr, "SDL_CreateWindow failed: %s\n", SDL_GetError());
        return 1;
    }

    // 创建渲染器
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == NULL) {
        fprintf(stderr, "SDL_CreateRenderer failed: %s\n", SDL_GetError());
        return 1;
    }

    // 设置随机数种子
    srand(time(NULL));

    char course[LENGTH]; // 定义游戏场地
    int player = LENGTH / 2; // 设置玩家起点
    int i, j;
    for (i = 0; i < LENGTH; i++) {
        int obstacle = rand() % 3; // 随机生成障碍物
        if (obstacle == 0) {
            course[i] = TREE;
        } else if (obstacle == 1) {
            course[i] = ROCK;
        } else {
            course[i] = BLANK;
        }
    }

    SDL_Rect player_rect = {player * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE}; // 玩家矩形
    SDL_Rect block_rect = {0, 0, BLOCK_SIZE, BLOCK_SIZE}; // 方块矩形

    // 游戏循环
    int quit = 0;
    while (!quit) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    quit = 1;
                    break;
                case SDL_KEYDOWN:
                    switch (event.key.keysym.sym) {
                        case SDLK_LEFT:
                            player--;
                            break;
                            (renderer, 255, 0, 0, 255);
                            break;
                        default:
                            continue;
                    }
                    block_rect.x = i * BLOCK_SIZE;
                    SDL_RenderFillRect(renderer, &block_rect);
            }
            // 渲染玩家
            SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
            SDL_RenderFillRect(renderer, &player_rect);

            SDL_RenderPresent(renderer); // 刷新窗口
            SDL_Delay(10); // 延迟 10 毫秒，控制游戏速度

            // 检测碰撞
            if (course[player] != BLANK) {
                printf("Game over!\n");
                break;
            }
        }

// 释放资源
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();

        return 0;
    }
}
