//
// Created by admin on 2023/2/9.
//
#include "bits/stdc++.h"
#include "iostream"
#include "cmath"

using namespace std;
int n;
int x;
bool judge= true;
int res[2];

void find(int a){
    for (int i = 2; i < a; i++ ) {
        for (int j = 2; j < i ; j++ ) {
            if (i%j==0) {
                judge = false;
                break;
            }
        }
        if(judge== true){
            for (int j = 2; j < a-i ; j++ ) {
                if ((a-i)%j==0){
                    judge= false;
                    break;
                }
            }
        }
        if (judge== true){

            res[0]=i;
            res[1]=a-i;
            break;
        }else{
            judge= true;
            continue;
        }
    }
}
void print(int a){
    find(a);
    cout<<a<<"="<<res[0]<<"+"<<res[1]<<endl;
}

int main(void){
    cin>>n;
    for (int i = 0; i < n; i++ ) {
        cin>>x;
        print(x);
    }
}