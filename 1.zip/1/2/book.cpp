#include <iostream>
#include "stdlib.h"
#include "string.h"
#include "stdio.h"
using namespace std;

typedef struct TicketNode
{
    char name[20];    // 订票人的名字，不超过20个字符，中间不带空格
    int price;        // 订票的价格
    TicketNode *next; // 指向下一个订票人的信息
} TicketNode;

/*YOU CAN ADD ANY FUNCTIONS IF YOU WANT*/

//创建一个时间表和一个价格表
TicketNode *TIME;
TicketNode *PRICE;
TicketNode *TAIL;
int n;
char *input;
char *names;
int ticket;

void sale(char *s,int n);
void display_by_time();
void display_by_price();
void refund(char *s);
int main()
{
    TIME=(TicketNode*) ::malloc(sizeof(TicketNode));
    PRICE=(TicketNode*) ::malloc(sizeof(TicketNode));
    TAIL=(TicketNode*) ::malloc(sizeof(TicketNode));

    TAIL=TIME;
    TIME->next=NULL;
    PRICE->next=NULL;

    input=(char *) ::malloc(100);
    names=(char *) ::malloc(100);
    cin>>n;

    for (int i = 0; i < n; i++ ) {
        cin>>input;

        if (!strcmp(input,"SALE")){
            cin>>names>>ticket;
            sale(names,ticket);
        }else if (!strcmp(input,"DISPLAY")){
            cin>>input;
            cin>>input;
            if (!strcmp(input,"TIME")){
                display_by_time();
            }else if (!strcmp(input,"PRICE")){
                display_by_price();
            }
        }else if (!strcmp(input,"REFUND")){
            cin>>input;
            refund(input);
        }
    }
//    ::free(TIME);
//    ::free(PRICE);
//    ::free(TAIL);
    /*YOUR CODE HERE*/
    return 0;
}

void sale(char *s,int n){
    TicketNode *p1= (TicketNode*)::malloc(sizeof(TicketNode));
    TicketNode *p2=(TicketNode*) ::malloc(sizeof(TicketNode));
    p1->price=n;
    p2->price=n;
    strcpy(p1->name,s);
    strcpy(p2->name,s);

    TicketNode *ptr2=PRICE;

    p1->next=TAIL->next;
    TAIL->next=p1;
    TAIL=p1;

    while (ptr2!=NULL&&ptr2->next!=NULL){
     if (ptr2->price<p2->price&&ptr2->next->price>p2->price)
         break;
     ptr2=ptr2->next;
    }
    p2->next = ptr2->next;
    ptr2->next = p2;
//    TicketNode *x1=TIME;
//    while (x1!=NULL){
//        cout<<x1->price<<endl;
//        x1=x1->next;
//    }
}
void display_by_time(){
    TicketNode *ptr=TIME->next;
    while (ptr!=NULL){
     cout<<ptr->name<<" "<<ptr->price<<endl;
     ptr=ptr->next;
    }
    cout<<endl;
    return;
}
void display_by_price(){
    TicketNode *ptr=PRICE->next;
    while (ptr!=NULL){
     cout<<ptr->name<<" "<<ptr->price<<endl;
     ptr=ptr->next;
    }
    cout<<endl;
    return;
}
void refund(char *s){
    TicketNode *ptr1=TIME->next;
    TicketNode *ptr11=TIME;
    TicketNode *ptr2=PRICE->next;
    TicketNode *ptr22=PRICE;
    while (ptr1!=NULL){
     if (!strcmp(ptr1->name,s)){
         ptr11->next=ptr1->next;
         ::free(ptr1);
         TAIL=TIME;
         while (TAIL->next!=NULL&&TAIL!=NULL){
             TAIL=TAIL->next;
         }
         break;
     } else {
         ptr11 = ptr1;
         ptr1 = ptr1->next;
     }
    }

    while (ptr2!=NULL){
     if (!strcmp(ptr2->name,s)){
         ptr22->next=ptr2->next;
         ::free(ptr2);
         break;
     } else {
         ptr22 = ptr2;
         ptr2 = ptr2->next;
     }
    }
}