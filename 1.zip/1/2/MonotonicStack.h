//
// Created by admin on 2023/2/14.
//

#ifndef INC_2_TEST_H
#define INC_2_TEST_H

#endif //INC_2_TEST_H


//
// Created by admin on 2023/2/14.
//
#include <iostream>
#include <stack>
using namespace std;

class MonotonicStack
{
private:
    stack<int> s;
public:
    int size();
    void pop();
    int top();
    int push(int element);
    int function(const int* arr,int n);
};

/*
其中成员变量s是stl中的stack类型的变量，是已经封装实现好的数据结构。
你可以使用它，使用s.size()将返回s内元素数量，使用s.push(int)将一个int型值入栈s，
s.top()返回s的栈顶元素，而s.pop()将弹出s的栈顶元素。
提示：在使用stack s时，进行s.pop()和s.top()前，应当检查s内是否有元素，否则容易引发段错误。
*/
