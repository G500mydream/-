
#include "MonotonicStack.h"

int MonotonicStack::size(){
    //TODO
    return s.size();
}

void MonotonicStack::pop(){
    //TODO
    if (!s.empty()) {
        s.pop();
    }
    return;
}

int MonotonicStack::top(){
    //TODO
     if (!s.empty()) {
        return s.top();
    }
    return 0;
}

int MonotonicStack::push(int element){
    //TODO
    if (!s.empty()){
        while (s.top()>element){
            s.pop();
            if (s.empty())
                break;
        }
        s.push(element);
    } else
        s.push(element);
    return 0;
}

int MonotonicStack::function(const int* arr,int n){
    //TODO
    int sum=0;
    for (int i = 0; i < n-1; i++ ) {
        int j=i;
        while (j<n){
            if (arr[j]<arr[i])
                break;
            j++;
        }
        if (j==n) {
            j--;
        }
        if (arr[j]<arr[i]){
            sum+=arr[i]-arr[j];
        } else {
            sum += arr[i];
        }
    }
    sum+=arr[n-1];
    return sum;
}

int main(){

    MonotonicStack *ms= new MonotonicStack;
    int arr[]={8,4,6,2,3};
    cout<<ms->function(arr,5);
    delete ms;
}