//
// Created by admin on 2023/2/9.
//
#include "bits/stdc++.h"
using namespace std;

int n;
int a;
int last;
int new_one;
int main(void ){
    cin>>n>>new_one;
    for (int i = 0; i < n; i++ ) {
        cin>>a;
        if (new_one>last&&new_one<a){
            cout<<i;
            return 0;
        }
        last=a;
    }
    cout<<n;
}