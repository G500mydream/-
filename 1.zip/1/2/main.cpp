#include "stdio.h"
#include "stdlib.h"
int* runningSum(int* nums, int numsSize, int* returnSize){
    returnSize=(int*)malloc(numsSize*sizeof(int));
    for(int i=0;i<numsSize;i++){
        if(i==0){
            returnSize[i]+=nums[i];
        }else{
            returnSize[i]=returnSize[i-1]+nums[i];
        }
    }
    return returnSize;
}
int main(){
    int *a;
    int *b;
    a=(int *) malloc(4*sizeof (int ));
    for (int i = 0; i < 4; ++i) {
        scanf("%d",&a[i]);
    }
    b= runningSum(a,4,b);
    for (int i = 0; i < 4; ++i) {
        printf("%d\n",b[i]);
    }
}