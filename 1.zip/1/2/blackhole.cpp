//
// Created by Ding Caiyan on 2023/2/9.
//
#include "bits/stdc++.h"
using namespace std;

int n;
int cnt=0;
int nums[7]={0};
bool analyse(int k,int ){
    if (k==495) { nums[cnt]=495;return true; }
    nums[cnt++]=k;
    if (k<100||k>999) return false;
    int a=k/100;
    int b=(k%100)/10;
    int c=k%10;
    if (a<b){
        int tmp=a;
        a=b;
        b=tmp;
    }
    if(a<c){
        int tmp=a;
        a=c;
        c=tmp;
    }
    if(b<c){
        int tmp=b;
        b=c;
        c=tmp;
    }
    if ((a*100+b*10+c)-(c*100+b*10+a)==495) {
        nums[cnt]=495;
        return true;
    }
    else if ((a*100+b*10+c)-(c*100+b*10+a)<1000&&(a*100+b*10+c)-(c*100+b*10+a)>99&&cnt<=8){
        return analyse((a*100+b*10+c)-(c*100+b*10+a),cnt);
    }
    else
        return false;
}

int main(void){
    cin>>n;
    if (analyse(n,cnt)) {
        if (cnt==0) { cout << nums[0];return 0;}

        for (int i = 0; i < cnt ; i++) {
            cout << nums[i] << "-";
        }
        cout<<nums[cnt];
    }
    else
        cout<<"NOT";
}