//
// Created by admin on 2023/2/9.
//
#include<iostream>
#include "iomanip"
#include "string.h"
#include "math.h"
using namespace std;

typedef struct
{
    int fuhao;
    int up;
    int down;
    /*YOUR CODE HERE*/
}Fraction;

int gcd(int a,int b){
    while(b!=0) {
        int temp = a % b;
        a = b;
        b = temp;
    }
    return a;
}

Fraction DecimalToFraction(char num[])
{
    Fraction res;
    if (strchr(num,'.')!=NULL){
        char *ptr=num;
        int tmp=0;
        while (*ptr!='.'){
            ptr++;
            tmp++;
        }
        int len= strlen(num)-tmp-1;//初始的分母

        char *b= strtok(num,".");
        strcat(b, strtok(NULL,"."));
        //转换分子

        int nums= ::atoi(b);

        res.up=nums/ gcd(nums, pow(10,len));
        res.down= pow(10,len)/ gcd(nums, pow(10,len));

    }else{
        res.up= ::atoi(num);
        res.down=1;
    }

    return res;
    /*YOUR CODE HERE*/
}

void FractionPrint(Fraction x)
{
    if (x.down==1){
        cout<<x.up;
        return;
    }
    cout<<x.up<<"/"<<x.down;
    /*YOUR CODE HERE*/
}

/*YOU CAN ADD ANY FUNCTIONS IF YOU WANT*/

int main()
{
    char num[20];
    cin>>num;

    Fraction result = DecimalToFraction(num);
    FractionPrint(result);
    return 0;
}

