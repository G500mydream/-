//
// Created by admin on 2023/3/14.
//
#include "TimeParser.h"

using namespace std;

TimeParser::TimeParser(string s)
{
    /* TODO */
    string hours;
    string minutes;
    string seconds;
    string judge1;
    string judge2;
    if (s.size()!=8){
        hour=-1;
        minute=-1;
        second=-1;
        return;
    }
    judge1=s.substr(2,1);
    judge2=s.substr(5,1);
    if ((judge1.compare(":")||judge2.compare(":"))){
        hour=-1;
        minute=-1;
        second=-1;
        return;
    }
    hours=s.substr(0,2);
    minutes=s.substr(3,4);
    seconds=s.substr(6,7);
    hour= stoi(hours);
    minute= stoi(minutes);
    second= stoi(seconds);
    if ((hour>=24||hour<0)||(minute>=60||minute<0)||(second>=60||second<0)){
        hour=-1;
        minute=-1;
        second=-1;
    }
    return;
}

int TimeParser::getHour()
{
    /* TODO */
    return hour;
}

int TimeParser::getMin()
{
    /* TODO */
    return minute;
}

int TimeParser::getSec()
{
    /* TODO */
    return second;
}
int main() {
    std::string s;
    std::cin >> s;
    TimeParser tp(s);

    std::cout << tp.getHour() << ' ';
    std::cout << tp.getMin() << ' ';
    std::cout << tp.getSec() << endl;

    return 0;
}