//
// Created by admin on 2023/3/14.
//

#ifndef UNTITLED3_MYLIST_H
#define UNTITLED3_MYLIST_H

#endif //UNTITLED3_MYLIST_H
//任务划分：首先要完成几个操作符的重载
//其次要完成这几个函数
#include "iostream"
using namespace std;
class MyArray{//创建一个MyArray对象就是创建了一个vector
    int * arr;
    int size;
public:
    int *_first;
    int *cur;//当前一个数的指针，用last应该可以实现遍历完成整个数组
    int *_end;
    friend class Iterator;//声明为友元使之能够独立的进行操作
    class Iterator{
    public:
        MyArray* ptr;
        Iterator(){
            ptr= nullptr;
        }
        ~Iterator(){
            delete ptr;
        }
        MyArray::Iterator operator =(MyArray::Iterator &a){
            MyArray::Iterator tmp;
            tmp.ptr=a.ptr;
            tmp.ptr->cur=a.ptr->cur;
            tmp.ptr->_first=a.ptr->_first;
            tmp.ptr->_end=a.ptr->_end;
            return tmp;
        }
        bool operator ==(MyArray::Iterator &a){
            MyArray::Iterator tmp;
            if (tmp.ptr->cur==a.ptr->cur){
                return true;
            }else{
                return false;
            }
        }
        bool operator !=(MyArray::Iterator &a){
            MyArray::Iterator tmp;
            if (tmp.ptr->cur!=a.ptr->cur){
                return true;
            }else{
                return false;
            }
        }
        MyArray::Iterator operator +(MyArray::Iterator &a){
            MyArray::Iterator tmp;
            tmp.ptr->cur+=a.ptr-tmp.ptr;
            return tmp;
        }
        void operator ++(MyArray::Iterator &c){
            if (c.ptr->cur!=c.ptr->_end){
                c.ptr->cur++;
            }
        }
        bool get(int & value) const{
            if ((_end-cur)/ sizeof(int )>=0){
                value=*cur;
                return true;
            }else{
                return false;
            }
        }
        bool put(int value){
            if (_end-cur>=0){
                *(this->arr)=value;
                return true;
            } else{
                return false;
            }
        }
        };

public:
    MyArray(){
        arr= nullptr;
        size=0;
    }
    MyArray(int sz){//根据给定的大小来创建数组
        arr= new int [sz];
        size=sz;
        _first=arr;
        _end=_first+size;
    };
    ~MyArray(){
        delete [] arr;
        delete[] _first;
    };

    Iterator begin(){
        Iterator tmp;
        tmp.ptr->_first=arr;
        tmp.ptr->cur=_first;
        return tmp;
    };
    Iterator end(){
        Iterator tmp;
        tmp.ptr= this;
        tmp.ptr->cur=_end;
        return tmp;
    };

};
// 单向链表实现的队列
//class MyList {
//private:
//    struct Node
//    {
//        char content;
//        Node *next;
//    } *head; // 链表的头节点
//
//public:
//    MyList();  // 构造函数
//    ~MyList(); // 析构函数
//    void add(char c);  // 添加新的节点
//    void removeNode(char c); // TODO: 移除所有content为c的节点
//    void printList(); // 从表头开始顺序打印元素
//};
//


