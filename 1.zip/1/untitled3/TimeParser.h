//
// Created by admin on 2023/3/14.
//

#ifndef UNTITLED3_TIMEPARSE_H
#define UNTITLED3_TIMEPARSE_H

#endif //UNTITLED3_TIMEPARSE_H
#include <iostream>
#include <string>
#include "string.h"

using namespace std;

// TODO: 补全TimeParser类并实现以下函数
class TimeParser {
    int hour;
    int minute;
    int second;
public:
    TimeParser(string s);  // 有参构造函数
    int getHour(); // 返回时
    int getMin(); // 返回分
    int getSec(); // 返回秒
};

// 你可以使用下面的main函数自己测试输入用例
//
// int main() {
//   std::string s;
//   std::cin >> s;
//   TimeParser tp(s);
//
//   std::cout << tp.getHour() << ' ';
//   std::cout << tp.getMin() << ' ';
//   std::cout << tp.getSec() << endl;
//
//   return 0;
// }