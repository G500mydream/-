#include <iostream>
#include <stdexcept>

class MyArray {
private:
    int *arr;  // 存储数据的指针
    int size;  // 数组大小
public:
    MyArray() : arr(nullptr), size(0) {}

    MyArray(int siz)  {
        if (siz==0){
            arr=nullptr;
            size=siz;
        }else{
            arr=new int [siz];
            size=(siz);
        }
    }

    ~MyArray() {
        delete[] arr;
    }

    // 拷贝构造函数
    MyArray(const MyArray &other) : arr(new int [other.size]), size(other.size) {
        for (int i = 0; i < size; i++) {
            arr[i] = other.arr[i];
        }
    }

    // 移动构造函数
    MyArray(MyArray &&other) : arr(other.arr), size(other.size) {
        other.arr = nullptr;
        other.size = 0;
    }

    // 拷贝赋值运算符
    MyArray &operator=(const MyArray &other) {
        if (this != &other) {
            delete[] arr;
            arr = new int [other.size];
            size = other.size;
            for (int i = 0; i < size; i++) {
                arr[i] = other.arr[i];
            }
        }
        return *this;
    }

    // 移动赋值运算符
    MyArray &operator=(MyArray &&other) {
        if (this != &other) {
            delete[] arr;
            arr = other.arr;
            size = other.size;
            other.arr = nullptr;
            other.size = 0;
        }
        return *this;
    }

    int &operator[](int index) {
        if (index < 0 || index >= size) {
            throw std::out_of_range("Index out of range");
        }
        return arr[index];
    }

    const int &operator[](int index) const {
        if (index < 0 || index >= size) {
            throw std::out_of_range("Index out of range");
        }
        return arr[index];
    }

    int getsize() const {
        return size;
    }

    void resize(int newSize) {
        int *newData = new int [newSize];
        int minSize = (newSize > size) ? size : newSize;
        for (int i = 0; i < minSize; i++) {
            newData[i] = arr[i];
        }
        delete[] arr;
        arr = newData;
        size = newSize;
    }
    // 迭代器类
    class Iterator {
    private:
        int *m_ptr;
    public:
        Iterator(int *ptr) : m_ptr(ptr) {}

        Iterator &operator++() {
            m_ptr++;
            return *this;
        }

        Iterator operator++(int) {
            Iterator tmp(m_ptr);
            m_ptr++;
            return tmp;
        }

        int &operator*() {
            return *m_ptr;
        }

        bool operator==(const Iterator &other) const {
            return m_ptr == other.m_ptr;
        }

        bool operator!=(const Iterator &other) const {
            return !(*this == other);
        }
        bool get(int &value){
            value=*(this->m_ptr);
            return true;
        }
        bool put(int value){
            *(this->m_ptr)=value;
            return true;
        }

    };
// 返回迭代器的起始位置和结束位置
    Iterator begin() {
        return Iterator(arr);
    }

    Iterator end() {
        return Iterator(arr + size);
    }
};
int main() {
    MyArray arr(10);

    for (int i = 0; i < arr.getsize(); i++) {
        arr[i] = i;
    }

    int i;
    for (auto it = arr.begin(); it != arr.end(); it++ ) {
        it.get(i);
        std::cout << *it << " ";
    }
    std::cout << std::endl;
//    auto it1=arr.begin();
//    for (int i = 0; i < 12; ++i) {
//        it1++;
//    }
//    std::cout<<*it1<< std::endl;
    return 0;
}