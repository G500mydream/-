//
// Created by admin on 2023/3/18.
//
/*
    自定义迭代器的实现
*/
#include <iostream>
using namespace std;
class num
{
    int *arr;
    int size; //数组的大小
public:
    num(int num) { //以下是一些基本的函数，用于设置值
        arr = new int(size);
    }
    ~num(){
        delete[] arr;
    }
    int get()
    {
        return val;
    }
    //以下是迭代器的部分
    class iterator
    {
        int pos;    //数字的下标
        num* obj;   //如果要在迭代器里面访问num的内容，必须要这个
    public:
        /*
            迭代器，要重载*,++,--
        */
        iterator(num* ptr,int n)
        {
            pos = n;
            obj = ptr;
        }
        iterator()
        {
            //空构造器
            pos = 0;
            obj = nullptr;
        }
        //操作符
        void operator++(){  //注意，这种没有参数的++重载的是前置的++   ++it
            pos++;
        }
        void operator++(int i){  //这种有任意int参数的重载的是后缀++  it++
            pos++;
        }
        void operator--(){
            pos--;
        }
        void operator--(int i){
            pos--;
        }
        int operator*()const{
            //13324 取第二位10位：  (13324%100)/10
            //num  去除第n位     (num % 10^(n))/ 10^(n-1)
            if(pos>=obj->size) return -1;
            if(pos==0)return obj->val%10;

            int o=10;
            int pow=0;
            while(pow<(pos-1)){
                // cout<<pow<<" "<<pos<<endl;
                o*=10;
                pow++;
            }
            return (obj->val%(o*10))/(o);
        }
        bool operator!=(const iterator& it){
            return it.pos!=pos;
        }
        bool operator==(const iterator& it){
            return it.pos==pos;
        }
    };
    //获取迭代器，常见的比如begin,end;
    iterator begin()
    {
        return iterator(this,0);
    }
    iterator end()
    {
        return iterator(this,size);
    }
};
int main()
{
    num a(123456789);
    for(auto it=a.begin();it!=a.end();it++){
        cout<<*it<<" ";
    }
    cout<<endl;

    return 0;
}