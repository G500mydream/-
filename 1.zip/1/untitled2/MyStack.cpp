//
// Created by admin on 2023/3/7.
//
// MyStack.cpp
#include "MyStack.h"

using namespace std;

// 构造函数
MyStack::MyStack()
{
    // TODO
    top = new Node;
    top = nullptr;
}

// 析构函数，你需要在这里归还额外申请的资源
MyStack::~MyStack()
{
    // TODO
    Node *ptr=top;
    while (ptr!= nullptr){
        delete ptr;
        ptr=ptr->next;
    }
}

// 字符c入栈
void MyStack::push(char c)
{
    // TODO
    Node *p= new Node;
    if (!top){
        top=p;
        p->next= nullptr;
        p->content=c;
    }else
    {
        p->next=top;
        top=p;
        p->content=c;
    }
}

// 栈顶元素出栈，返回出栈元素（我们没有定义空栈pop操作，测试用例中不会涉及）
char MyStack::pop()
{
    char result = 0;
    // TODO
    result=top->content;
    Node *ptr=top;
    top=top->next;
    delete ptr;
    return result;
}

// 返回栈的大小（栈内元素数量）
int MyStack::size()
{
    int result = 0;
    // TODO
    Node *ptr=top;
    while (ptr!= nullptr){
        result++;
        ptr=ptr->next;
    }
    return result;
}

int main() {
    MyStack s;
    s.push('N');
    s.push('J');
    s.push('U');
    cout <<s.size() << endl; // 3
    cout <<s.pop()<< endl; // U
    cout << s.pop()<< endl; // J
    cout << s.pop() << endl; // N
    cout << s.size() << endl; // 0
    return 0;
}
