//
// Created by admin on 2023/2/28.
//
#include "iostream"
#include "string.h"
#include "bits/stdc++.h"
#include "stack"

using namespace std;


int n;
int input;
std::stack<int> a;

int main(){

    cin>>n;
    for (int i = 0; i < n; i++ ) {
        cin>>input;

        if (a.empty()){
            a.push(input);
        } else{
            if (a.top()+2==input){
                a.pop();
            } else{
                a.push(input);
            }
        }
    }
    if (a.empty()){
        cout<<"true"<<endl;
    } else{
        cout<<"false"<<endl;
    }
}