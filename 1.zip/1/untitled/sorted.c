//
// Created by admin on 2023/2/17.
//
#include "stdio.h"
#include "stdbool.h"

int T;
int n;
int m;
int search;
int pri[1005]={0};

int find_number(int pos){
    for (int i = 0; i < 1005; i++ ) {
        return pri[pos-1];
    }
}
void change(int a){

    int tmp= find_number(a);
    for (int i = a-1; i >0 ; i-- ) {
        pri[i]=pri[i-1];
    }
    pri[0]=tmp;
}

void check(){
    bool judge=true;
    for (int i = 0; i < n-1; i++ ) {
        if (pri[i]>pri[i+1]){
            printf("mayi is a good teacher\n");
            judge=false;
            break;
        }
    }
    if(judge==true){
        printf("I love C programming language\n");
    }
}

void clear(){
    for (int i = 0; i < n; i++ ) {
        pri[i]=0;
    }
}
int main(){

    scanf("%d",&T);
    for (int i = 0; i < T; i++ ) {
        scanf("%d%d",&n,&m);
        for (int j = 0; j < n; j++ ) {
            scanf("%d",&pri[j]);
        }
        for (int j = 0; j < m; j++ ) {
            scanf("%d",&search);
            change(search);
        }
        check();
        clear();
    }
}