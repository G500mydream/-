//
// Created by admin on 2023/2/17.
//
#include "stdio.h"
#include "stdbool.h"
#include "stdlib.h"
#include "string.h"

int n;
int q;
int *arr;
int search;

int look(int a){
    int left=0;
    int right=n-1;
    int pos=left+((right-left)>>1);
    if(arr[0]==a){
        return 0;
    } else if(arr[right]==a){
        return right;
    } else {
        for (; arr[pos] != a && left <= right ; ) {
            if (a > arr[pos]) {
                left = pos+1;
                pos = left+((right-left)>>1);
            } else if (a < arr[pos]) {
                right = pos-1;
                pos = left+((right-left)>>1);
            }
        }
    }
    if(arr[pos]==a){
        return pos;
    } else
        return -1;
}
main(){
/*
    scanf("%d%d",&n,&q);
    arr=(int *) malloc(n*sizeof (int ));
    for (int i = 0; i < n; i++ ) {
        scanf("%d",&arr[i]);
    }
    for (int i = 0; i < q; i++ ) {
        scanf("%d",&search);
        printf("%d\n", look(search));
    }
    */
//int x=8;
char s1[10]="ABCDE";
char s2[10]="xyz";

    strcpy(s1,s2);
    printf("%s",s1);

//    printf("%c",s[2]);
//    printf("%d",x%=x-1);
}