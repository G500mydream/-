#include "Polynomial.h"
#include <assert.h>

Polynomial::Polynomial(const vector<int> &coefficients) {
coefficients_ = coefficients;
}

Polynomial::Polynomial(const Polynomial &other) {
this->coefficients_ = other.coefficients_;
}

Polynomial add(const Polynomial &p1, const Polynomial &p2) {
// TODO
}

Polynomial derivate(const Polynomial &p) {
// TODO
}

void Polynomial::output() const {
// TODO
}