#include "MyArray.h"

int main() {
    int v=-1;
    int res;
    MyArray arr(2);
    arr[0]=2;
    arr[1]=3;
    MyArray::Iterator iter=arr.begin();
    cout<<boolalpha<<iter.get(res)<<" "<<res<<endl;
    arr.~MyArray();
    cout<<boolalpha<<iter.get(res)<<endl;

    cout<<"reallydone";
    return 0;
}