//
// Created by admin on 2023/3/19.
//

#ifndef UNTITLED4_MYARRAY_H
#define UNTITLED4_MYARRAY_H

#endif //UNTITLED4_MYARRAY_H
#include "iostream"
using namespace std;
class MyArray{
    int * arr;
    int size;
public:
    class Iterator{
    private:
        int *ptr;
        int *first;
        int lenth;
        int default_value;
    public:
        static int flag;
        Iterator(int *p= nullptr,int *q= nullptr,int tmp=0):ptr(p),first(q),lenth(tmp),default_value(0){}
        ~Iterator(){}
        int& operator*() {
            if (ptr== nullptr){
                return default_value;
            }
            return *ptr;
        }
        Iterator& operator++() {
            if (ptr) {
                ptr++;
            }
            return *this;
        }
        Iterator operator++(int) {
            Iterator tmp(ptr,first,lenth);
            if (ptr) {
                ptr++;
            }
            return tmp;
        }
        Iterator& operator--(){
            if (ptr!= nullptr)
            {
                ptr--;
            }
            return *this;
        }
        Iterator operator--(int ){
            Iterator tmp(ptr,first,lenth);
            if (ptr!= nullptr) {
                ptr--;
            }
            return tmp;
        }
        Iterator operator+(int len) const{
            if (ptr) {
                return Iterator(ptr + len,first,lenth);
            }
            return Iterator(ptr,first,lenth);
        }
        Iterator operator-(int len) const{
            if (ptr) {
                return Iterator(ptr - len,first,lenth);
            }
            return Iterator(ptr,first,lenth);
        }
        bool operator!=(const MyArray::Iterator& other ){
            return ptr!=other.ptr;
        }
        bool operator==(const MyArray::Iterator&other ){
            return ptr==other.ptr;
        }
        bool get(int& value){
            if (flag==0){
                return false;
            }
            if (ptr== nullptr){
                return false;
            }
            if (ptr-first< lenth&&ptr-first>=0) {
                value = *ptr;
                return true;
            }else{
                return false;
            }
        }
        bool put(int value){
            if (flag==0){
                return false;
            }
            if (ptr== nullptr){
                return false;
            }
            if (ptr-first<lenth&&ptr-first>=0) {
                *ptr = value;
                return true;
            } else{
                return false;
            }
        }
    };
    friend class Iterator;
public:
    MyArray(int siz=0):size(siz){
        if (siz==0){
            arr= nullptr;
        }else{
            arr= new int [siz];
        }
    };
    ~MyArray(){
        MyArray::Iterator::flag=0;
        delete []arr;
    }
    MyArray& operator=(const MyArray& other) {
        if (this != &other) {
            delete[] arr;
            size = other.size;
            if (size == 0) {
                arr = nullptr;
            } else {
                arr= new int[size];
                for (int i = 0; i < size; i++) {
                    arr[i] = other.arr[i];
                }
            }
        }
        return *this;
    }
    int& operator[](int index) {
        return arr[index];
    }
    int getSize() {
        return size;
    }
    Iterator begin(){
        return Iterator(arr,arr,size);
    }
    Iterator end(){
        if (arr== nullptr){
            return Iterator(arr,arr,size);
        }
        return Iterator(arr+size,arr,size);
    }
};
int MyArray::Iterator::flag=1;