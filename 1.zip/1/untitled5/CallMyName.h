//
// Created by admin on 2023/3/21.
//

#ifndef UNTITLED5_CALLMYNAME_H
#define UNTITLED5_CALLMYNAME_H

#endif //UNTITLED5_CALLMYNAME_H
#include <string>
#include "string.h"
#include "stdlib.h"
using namespace std;

class CallMyName
{
    void** all_functions;
public:
    CallMyName(void* af[3]){
        all_functions=af;
    }
    int call(const string &my_call)
    {
        //TODO
        char tmp[20];
        strcpy(tmp,my_call.c_str());
        int left,right;
        if (tmp[6]=='A'){
            char *s1= strtok(tmp,"(");
            s1= strtok(nullptr,"(");
            char *num1= strtok(s1,",");
            s1= strtok(nullptr,",");
            char *num2= strtok(s1,")");
            left= ::atoi(num1);
            right= ::atoi(num2);
            void *ptr;
            ptr=all_functions[0];
            return ((int (*)(int,int ))ptr)(left,right);
        }else if (tmp[6]=='S'){
            char *s1= strtok(tmp,"(");
            s1= strtok(nullptr,"(");
            char *num1= strtok(s1,",");
            s1= strtok(nullptr,",");
            char *num2= strtok(s1,")");
            left= ::atoi(num1);
            right= ::atoi(num2);
            void *ptr;
            ptr=all_functions[1];
            return ((int (*)(int,int ))ptr)(left,right);
        }else if (tmp[6]=='H'){
            char *s1= strtok(tmp,"(");
            s1= strtok(nullptr,"(");
            char *num1= strtok(s1,",");
            s1= strtok(nullptr,",");
            char *num2= strtok(s1,")");
            left= ::atoi(num1);
            right= ::atoi(num2);
            void *ptr;
            ptr=all_functions[2];
            return ((int (*)(int,int ))ptr)(left,right);
        }
        return 0;
    }
};
