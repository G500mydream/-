//
// Created by admin on 2023/3/21.
//
#include "SmartPointer.h"

SmartPointer::SmartPointer(const SmartPointer &sptr)
{
    if (&sptr== this){
        return;
    }
    // 复制指针和引用计数器
    pointer = sptr.pointer;
    ref_cnt = sptr.ref_cnt;
    // 引用计数器加一
    if (ref_cnt != nullptr)
    {
        (*ref_cnt)++;
    }
}
//SmartPointer::SmartPointer(const SmartPointer &sptr)
//{
//    if (sptr.pointer == nullptr||sptr.ref_cnt== nullptr) {
//        pointer = nullptr;
//        ref_cnt = new int(0);
//    } else {
//        pointer = sptr.pointer;
//        ref_cnt = sptr.ref_cnt;
//        (*ref_cnt)++;
//    }
//}
void SmartPointer::assign(const SmartPointer &sptr) {
    // 自我赋值
    if (this == &sptr) {
        return;
    }

    // 首先将本对象原有的引用计数器减一
    if (ref_cnt != nullptr) {
        (*ref_cnt)--;
        // 如果原有的引用计数器为0，说明本对象是最后一个引用指向该指针，需要删除它指向的对象
        if (*ref_cnt == 0) {
            delete pointer;
            delete ref_cnt;
        }
    }

    // 复制新的指针和引用计数器
    pointer = sptr.pointer;
    ref_cnt = sptr.ref_cnt;
    // 引用计数器加一
    if (ref_cnt != nullptr) {
        (*ref_cnt)++;
    }
}
//void SmartPointer::assign(const SmartPointer &sptr)
//{
//    if (ref_cnt == nullptr) {
//        if (sptr.pointer != nullptr && sptr.ref_cnt != nullptr) {
//            ref_cnt = new int(0);
//            (*ref_cnt) = (*sptr.ref_cnt);
//            (*ref_cnt)++;
//            pointer = sptr.pointer;
//            (*sptr.ref_cnt)++;
//        } else {
//            ref_cnt = nullptr;
//            pointer = nullptr;
//            return;
//        }
//    } else {
//        if (ref_cnt != sptr.ref_cnt) {
//            (*ref_cnt)--;
//            if (*ref_cnt == 0) {
//                if (pointer != nullptr) {
//                    delete pointer;
//                }
//                if (ref_cnt != nullptr) {
//                    delete ref_cnt;
//                }
//            }
//            pointer = nullptr;
//            ref_cnt = nullptr;
//            if (sptr.pointer != nullptr && sptr.ref_cnt != nullptr) {
//                pointer = sptr.pointer;
//                ref_cnt = sptr.ref_cnt;
//                (*ref_cnt)++;
//            }
//        }
//    }
//}
SmartPointer::~SmartPointer() {
    // 将引用计数器减一
    if (ref_cnt != nullptr)
    {
        (*ref_cnt)--;
        // 如果引用计数器为0，说明本对象是最后一个引用指向该指针，需要删除它指向的对象
        if (*ref_cnt == 0)
        {
            delete pointer;
            delete ref_cnt;
        }
    }
}
//SmartPointer::~SmartPointer()
//{
//    (*ref_cnt)--;
//    if ((*ref_cnt)==0){
//        delete pointer;
//        delete ref_cnt;
//        pointer= nullptr;
//        ref_cnt= nullptr;
//    }
//}
int main(){
    SmartPointer sp1(new Node(123));
    sp1.~SmartPointer();
    sp1.assign(SmartPointer());//测试空指针赋值
    sp1.assign(*(new SmartPointer(new Node(456))));//Node 456仍然被堆空间中的某个指针持有，所以不会被释放


}
//void SmartPointer::assign(const SmartPointer &sptr)
//{
//    if (ref_cnt== nullptr){
//        if (sptr.pointer!= nullptr){
//            ref_cnt=new int (0);
//            (*ref_cnt)=(*sptr.ref_cnt);
//            (*ref_cnt)++;
//            (*sptr.ref_cnt)++;
//            pointer=sptr.pointer;
//        }else{
//            return;
//        }
//    }else{
//        (*ref_cnt)--;
//        if (*ref_cnt==0){
//            delete pointer;
//            delete ref_cnt;
//        }
//        pointer=sptr.pointer;
//        ref_cnt=sptr.ref_cnt;
//        (*ref_cnt)++;
//    }
//}

//SmartPointer::SmartPointer(const SmartPointer &sptr)
//{
//    if (sptr.pointer== nullptr){
//        pointer= nullptr;
//        ref_cnt=new int (0);
//        return;
//    }else{
//        pointer=sptr.pointer;
//        ref_cnt=new int (1);
//        (*ref_cnt)= (*sptr.ref_cnt);
//        (*ref_cnt)++;
//        (*sptr.ref_cnt)++;
//    }
//}