#include <iostream>

#include "CallMyName.h"
#include <iostream>
using namespace std;
int funcMyAdd(int a, int b)
{
    return a + b;
}
int funcMySub(int a, int b)
{
    return a - b;
}
int funcMyHash(int a, int b)
{
    return a*b%120;
}
void *functions[3] = {(void *)funcMyAdd, (void *)funcMySub, (void *)funcMyHash};
int main()
{
   CallMyName call(functions);
//   cout << call.call("funcMyAdd(1,2)") << endl;
//   cout << call.call("funcMySub(1,2)") << endl;
   cout << call.call("funcMyHash(1,2)") << endl;
   return 0;
}
