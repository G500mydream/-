//
// Created by admin on 2023/2/23.
//
#include "iostream"
#include "stdbool.h"
using namespace std;

int m,n;
int map[52][52]={0};
int new_map[52][52]={0};
bool out= false;

void init_map(){
    for (int i = 0; i <= n+1; i++ ) {
        map[0][i]=2;
        map[m+1][i]=2;
    }
    for (int i = 0; i <= m+1; i++ ) {
        map[i][0]=2;
        map[i][n+1]=2;
    }
    for (int i = 0; i <= m+1; i++ ) {
        for (int j = 0; j <= n+1; j++ ) {
            new_map[i][j]=map[i][j];
        }
    }
}

bool merge(){
    for (int i = 0; i <= m+1; i++ ) {
        for (int j = 0; j <= n+1; j++ ) {
            new_map[i][j]=map[i][j];
        }
    }
    for (int i = 1; i <= m; i++ ) {
        for (int j = 1; j <= n; j++ ) {
            if (map[i][j]==1){
                if (map[i-1][j]==0){
                    map[i-1][j]=1;
                } else if (map[i+1][j]==0){
                    map[i+1][j]=1;
                } else if (map[i][j-1]==0){
                    map[i][j-1]=1;
                } else if (map[i][j+1]==0){
                    map[i][j+1]=1;
                }
            }
        }
    }
    for (int i = 1; i <= m; i++ ) {
        for (int j = 1; j <= n; j++ ) {
            if (map[i][j]!=new_map[i][j]){
                return false;
            }
        }
    }
    return true;
}

int main(){
    cin>>m>>n;
    init_map();
    for (int i = 1; i <= m; i++ ) {
        for (int j = 1; j <=n ; j++ ) {
            cin>>map[i][j];
        }
    }
    while (merge()!= true);
    for (int i = 1; i <=m ; i++ ) {
        for (int j = 1; j <n ; j++ ) {
            cout<<map[i][j]<<" ";
        }
        cout<<map[i][n]<<endl;
    }


}



//    for (int i = 0; i < m+2; i++ ) {
//        for (int j = 0; j < n+2; j++ ) {
//            cout<<map[i][j]<<" ";
//        }
//        cout<<endl;
//    }