#include <iostream>
using namespace std;
typedef struct node{
    int data;
    struct node *next;
}node;

node *linklist;
node *new_linklist;
int n;
int k;

void reverse_plus(){
    node *ptr=linklist;
    while (ptr!=NULL){
        if (ptr->data==k){
            ptr=ptr->next;
            continue;
        } else{
            node *p=new node ;
            if (!new_linklist){
                p->data=ptr->data;
                p->next=NULL;
                new_linklist=p;
            } else{
                p->data= ptr->data;
                p->next=new_linklist;
                new_linklist=p;
            }
        }
        ptr=ptr->next;
    }
    node *t=new_linklist;
    while (t!=NULL&&t->next!=NULL){
        std::cout<<t->data<<" ";
        t=t->next;
    }
    cout<<t->data;
}

int main() {
    linklist=NULL;
    new_linklist=NULL;
    node *ptr=linklist;
    std::cin>>n;
    for (int i = 0; i < n; i++ ) {
        node *p= new node ;
        std::cin>>p->data;
        if (!linklist){
            linklist=p;
            p->next=NULL;
            ptr=p;
        } else{
            ptr->next=p;
            p->next=NULL;
            ptr=p;
        }
    }

    std::cin>>k;

    reverse_plus();
    return 0;
}
