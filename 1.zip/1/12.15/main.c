/*
#include "stdlib.h"
#include "stdio.h"
#include "string.h"

//创建一个单链表
struct node {
    int a;
    struct node *b;
};

int main(void )
{
    struct node *head=NULL;
    
}
 */