/*
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

int len1;
int len2;
int k;
int *memory;

void sort(int a[],int n)
{
    int tmp;
    for (int i = 1; i < n; i++) {
        for (int j = 0; j < n-i; j++) {
            if(a[j]>a[j+1])
            {
                tmp=a[j];
                a[j]=a[j+1];
                a[j+1]=tmp;

            }
        }
    }
}

struct Node {    //链表结点
    int data;    //数据
    struct Node* link;    //指向下一个结点的指针
};

// 尾插法建立单链表：返回单链表的头指针

struct Node* buildLinkedList(int* arr, int n); // 尾插法建立单链表
void printLinkedList(struct Node* head);       // 打印链表

int main(void )
{
    memory=(int *) malloc(1000000*sizeof (int ));

    scanf("%d",&len1);
    for (int i = 0; i < len1; i++) {
        scanf("%d",(memory+i));
    }
    scanf("%d",&len2);
    for (int i = 0; i < len2; i++) {
        scanf("%d",(memory+i+len1));
    }
    scanf("%d",&k);

    sort(memory,len1+len2);

    struct Node* head = NULL;	//声明一个指针变量head

    head = buildLinkedList(memory, len1+len2);
    printLinkedList(head);
    printf("\n");
    printf("%d",*(memory+len1+len2-k));
    free(memory);

}

struct Node* buildLinkedList(int* arr, int n){
    struct Node*p,*pre,*head;
    head=(struct Node*)malloc(sizeof(struct Node));
    head->link=NULL;
    pre=head;
    for(int i=0;i<n;i++){
        p=(struct Node*)malloc(sizeof(struct Node));
        p->data=arr[i];
        p->link=NULL;
        pre->link=p;
        pre=p;
    }
    return head;
}
void printLinkedList(struct Node* head){
    head=head->link;
    printf("%d",head->data);
    head=head->link;
    while(head!=NULL){
        printf(" %d",head->data);
        head=head->link;
    }
}
*/