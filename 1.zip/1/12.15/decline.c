//
// Created by admin on 2023/1/2.
//
#include "stdio.h"
#include "string.h"
#include "stdbool.h"
#include "stdlib.h"

int main(void ){
    printf("hello");
}