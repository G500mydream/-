/*
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define ElemType int

typedef struct LNode{
    ElemType Data;            //数据域
    struct LNode *Next;      //指针域
}LNode,*LinkList;

int *a;
LinkList CreateList_Head(LinkList L1,int n,int *a)
{
    LinkList s;int x;
    int i=0;
    L1= (LNode*)malloc(sizeof(LNode));     //创建头结点
    L1->Next=NULL;
    scanf("%d",&x);
    *a=x;
    while(i<n){
        i++;
        s=(LNode*)malloc(sizeof(LNode));
        s->Data=x;
        s->Next=L1->Next;
        L1->Next=s;                          //插入结点
        if(i>=n)
            break;
        scanf("%d",&x);
        *(a+i)=x;

    }
    return L1;
}
void PrintList(LinkList L)
{
    LinkList p;
    p=L->Next;

    while(p!=NULL)
    {
        printf("%d",p->Data);
        p=p->Next;
        if(p==NULL)
            break;
        printf(" ");
    }
    printf("\n");
}

bool judge(LinkList L,int *a)
{
    LinkList p;
    p=L->Next;
    int i=0;
    while (p!=NULL)
    {
        if(p->Data!=*(a+i))
            return false;
        p=p->Next;
        i++;
    }
    return true;
}
int main(void )
{
    int n;
    scanf("%d",&n);
    a=(int *) malloc(1000000*sizeof (int ));

    LinkList L;
    L= CreateList_Head(L,n,a);

    PrintList(L);

    if(judge(L,a))
        printf("true\n");
    else
        printf("false\n");
}
 */