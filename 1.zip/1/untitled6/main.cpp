#include <iostream>
#include "Matrix.h"

using namespace std;
// 补充代码

int main() {
    Matrix m1(3, 4);
    int i, j;
    for (i = 0; i < 3; ++i) {
        for (j = 0; j < 4; j++) {
            m1[i][j] = i * 4 + j;
        }
    }
    for (i = 0; i < 3; ++i) {
        for (j = 0; j < 4; j++) {
            cout << m1(i, j) << ", ";
        }
        cout << endl;
    }
    cout << "next" << endl;
    Matrix m2;
    m2 = m1;
    for (i = 0; i < 3; ++i) {
        for (j = 0; j < 4; j++) {
            cout << m2[i][j] << ",";
            m2[i][j] += 1;
        }
        cout << endl;
    }
    for (i = 0; i < 3; ++i) {
        for (j = 0; j < 4; j++) {
            cout << m1(i, j) << ", ";
        }
        cout << endl;
    }
    for (i = 0; i < 3; ++i) {
        for (j = 0; j < 4; j++) {
            cout << m2(i, j) << ", ";
        }
        cout << endl;
    }
    return 0;
}