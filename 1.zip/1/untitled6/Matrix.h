//
// Created by admin on 2023/3/23.
//

#ifndef UNTITLED6_MATRIX_H
#define UNTITLED6_MATRIX_H

#endif //UNTITLED6_MATRIX_H

class Matrix {
    int row, col;
    int **arr;
public:
    Matrix() : row(0), col(0), arr(nullptr) {}

    explicit Matrix(const int a, const int b) : row(a), col(b) {
        if (row > 0 && col > 0) {
            arr = new int *[row];
            for (int i = 0; i < row; i++) {
                arr[i] = new int[col];
            }
        } else {
            row = 0;
            col = 0;
            arr = nullptr;
        }
        return;
    }

    Matrix(const Matrix &other) {
        row = other.row;
        col = other.row;
        if (row > 0 && col > 0) {
            arr = new int *[row];
            for (int i = 0; i < row; i++) {
                arr[i] = new int[col];
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    arr[i][j] = other.arr[i][j];
                }
            }
        } else {
            row = 0;
            col = 0;
            arr = nullptr;
        }
        return;
    }

    ~Matrix() {
        if (arr) {
            for (int i = 0; i < row; i++) {
                delete[] arr[i];
            }
            delete arr;
        }
        return;
    }

    Matrix &operator=(const Matrix &B) {
        if (arr) {
            for (int i = 0; i < row; i++) {
                delete[] arr[i];
            }
            delete arr;
        }
        row = B.row;
        col = B.col;
        if (row > 0 && col > 0) {
            arr = new int *[row];
            for (int i = 0; i < row; i++) {
                arr[i] = new int[col];
            }
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    arr[i][j] = B.arr[i][j];
                }
            }
        } else {
            row = 0;
            col = 0;
            arr = nullptr;
        }
        return *this;
    }

    int *operator[](int address) {
        return address >= this->row ? nullptr : this->arr[address];
    }

    int &operator()(int x, int y) {
        return arr[x][y];
    }
};
