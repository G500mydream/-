#include "stdio.h"
#include "stdlib.h"
#include "string.h"
//再细分一点任务吧，先完成二叉树的创建，我草泥马
//再完成二叉树的遍历输出，草泥马
int n,q;
int sum=0;

typedef struct node{
    char *string;
    struct node*left;
    struct node*right;
    struct node*back;//声明一个反向的指针
}Node;//这里是为了声明树的节点
Node *search(Node*tree,char *s){
    if(tree){
        if(!strcmp(s,tree->string)){
            return tree;
        }
        Node *temp= search(tree->left,s);
        if(!temp){
            return search(tree->right,s);
        } else
            return temp;
    } else
        return NULL;
}
void destroy_tree(Node *tree){
    if(!tree){
        return;
    }
    destroy_tree(tree->left);
    destroy_tree(tree->right);
    free(tree);
}
int query_tree(Node *T){

    if(T){
        sum++;
    }
    if(T->left) query_tree(T->left);
    if(T->right) query_tree(T->right);
    return sum;
}
void preOrder(Node *T){
    if(T){
        printf("%s\n",T->string);
        preOrder(T->left);
        preOrder(T->right);
    } else
        return;
}

int main(void ){
    scanf("%d%d",&n,&q);//此处输入两个值开始，完成输入部分
    //我们先把任务分解为两部分，先完成二叉树的建立

    Node *root= malloc(sizeof (Node));
    root->left=NULL;
    root->right=NULL;
    for (int i = 0; i < n; i++ ) {
        char *input1= malloc(11);
        char *input2= malloc(11);
        scanf("%s",input1);
        scanf("%s",input2);
        if(!strcmp(input2,"~~~")){
            root->string=input1;
        } else{
            Node *p= malloc(sizeof (Node));
            p->left=NULL;
            p->right=NULL;
            p->string=input1;
            Node *t;
            t= search(root,input2);
            if(t->left==NULL){
                t->left=p;
                p->back=t;
            } else{
                t->right=p;
                p->back=t;
            }
        }
    }
//    preOrder(root);前序遍历用于测试二叉树是否创建成功
    for (int i = 0; i < q; i++ ) {
        sum=0;
        char *input3= malloc(11);
        char *input4= malloc(11);
        scanf("%s",input3);
        scanf("%s",input4);
        if(!strcmp(input3,"remove")){
            Node *temp= search(root,input4);
            Node *temp2=temp->back;
            if(temp->back->left==temp){
                destroy_tree(temp);
                temp2->left=NULL;//将左支制空
            } else{
                destroy_tree(temp);
                temp2->right=NULL;
            }
        } else{
            printf("%d\n",query_tree(search(root,input4)));
        }
        free(input3);
        free(input4);
    }
}