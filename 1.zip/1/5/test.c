//
// @author: 冲哥
// @date: 2021/6/5 11:24
// @description: 实现简单计算器功能（加减乘除）
#include <stdio.h>

float addition(float num1, float num2);
float subtraction(float num1, float num2);
float multiplication(float num1, float num2);
float division(float num1, float num2);
void menu();

int main() {
    float result;
    float num1, num2;
    int select;
    printf("输入两个数，逗号分隔。\n");
    scanf("%f,%f", &num1, &num2);
    menu();
    scanf("%d", &select);
    switch (select) {
        case 1: {
            result = addition(num1, num2);
            printf("%f + %f = %f\n",num1,num2,result);
            break;
        }
        case 2: {
            result = subtraction(num1, num2);
            printf("%f - %f = %f\n",num1,num2,result);
            break;
        }
        case 3: {
            result = multiplication(num1, num2);
            printf("%f * %f = %f\n",num1,num2,result);
            break;
        }
        case 4: {
            result = division(num1, num2);
            printf("%f / %f = %f\n",num1,num2,result);
            break;
        }
        default:{
            printf("输入有误，程序退出！");
            break;
        }
    }
    return 0;
}

void menu(){
    printf("********************简单计算器**********************\n");
    printf("*        1 加法                                 *\n");
    printf("*        2 减法                                 *\n");
    printf("*        3 乘法                                 *\n");
    printf("*        4 除法                                 *\n");
    printf("*     输入任意非功能选项序号退出计算器      *\n");
    printf("*************************************************\n");
    printf("输入菜单项：\n");
}

float addition(float num1, float num2){
    return num1 + num2;
}

float subtraction(float num1, float num2){
    return num1 - num2;
}

float multiplication(float num1, float num2){
    return num1 * num2;
}

float division(float num1, float num2){
    return num1 / num2;
}