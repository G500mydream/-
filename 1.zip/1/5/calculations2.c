//
// Created by admin on 2023/1/7.
//
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdbool.h"

typedef struct token{
    enum {
        VAR,NUM,OP,ERROR
    }type;
    char str[32];
}Token;
//接下来我们将会使用Token类型的数组来存储我们所输入的词法
typedef struct value{
    enum {
        INT,FLOAT
    }type;
    union {
        int iVal;
        double fVal;
    }val;
}Value;
char *input;
Token tokens[1024];
Value calculation[1024];
int n=0;
Value error;

/*
Value eval(int l,int r){
    if(l>r){
        error.type=ERROR;
        return error;
    } else if(l==r){

    }
}
 */

int main(void ){
    while (scanf("%s",tokens[n++].str)!=EOF){
        char c=getchar();
        if(c=='\n'){
            for (int i = 0; i < n; i++ ) {//我们待会儿再过来拓展浮点数支持功能
                //现在我们要实现的是整数数字的直接运算，此处为第一步进行词法分析，因为我们还需要完成一个变量赋值的操作
                //现在先把直接运算的部分做出来吧
                if(strchr(tokens[i].str,'.')==NULL){
                    sscanf(tokens[i].str,"%d",&calculation[i].val.iVal);
                } else{
                    sscanf(tokens[i].str,"%lf",&calculation[i].val.fVal);
                }
                if((!strcmp(tokens[i].str,"+"))||(!strcmp(tokens[i].str,"-"))||(!strcmp(tokens[i].str,"*"))||(!strcmp(tokens[i].str,"/"))){
                    tokens[i].type=OP;
                } else if(((*(tokens[i].str)>=65)&&(*(tokens[i].str)<=90))||(*(tokens[i].str)==95)||((*(tokens[i].str)>=97)&&(*(tokens[i].str)<=122))){
                    tokens[i].type=VAR;
                } else if((*(tokens[i].str)>=48&&*(tokens[i].str)<=57)&&calculation[i].val.iVal!=0){
                    tokens[i].type=NUM;
                } else{tokens[i].type=ERROR;return 0;}
            }
            for (int i = 0; i < n; i++ ) {
                printf("%d\n",calculation[i].val.iVal);
            }
            n=0;
        }
    }
}